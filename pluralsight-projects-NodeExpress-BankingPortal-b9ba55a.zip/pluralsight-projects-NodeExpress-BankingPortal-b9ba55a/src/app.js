const fs = require('fs');
const path = require('path');
const data = require('./data')

const express = require('express');

const app = new express();

app.set('views', path.join(__dirname, '/views'));
app.set('view engine', 'ejs');

app.use(express.static(path.join(__dirname, '/public')));

const { accounts, users, writeJSON } = data;


const accountRoutes = require('./routes/accounts')
const servicesRoutes = require('./routes/services')
app.use(express.urlencoded({extended:true}));

app.get('/', function(req, res){
    res.render('index', { title: 'Account Summary', accounts: accounts })
} );

app.use('/account', accountRoutes);

app.get('/profile', function(req, res){
    res.render('profile', { user: users[0] })
})

app.use('/services', servicesRoutes)


app.listen(3000, function(){
    console.log('PS Project Running on port 3000!')
})